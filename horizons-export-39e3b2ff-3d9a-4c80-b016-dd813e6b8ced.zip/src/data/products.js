
export const products = [
  // Compression Sleeves
  {
    id: 'sleeve-black-1',
    name: 'Premium Compression Sleeve',
    category: 'Sleeves',
    price: 29.99,
    rating: 4.8,
    reviewCount: 324,
    image: 'https://images.unsplash.com/photo-1685045745260-cd6c01b3c4de',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Black', 'Navy', 'Purple', 'Rose'],
    description: 'Advanced compression technology for optimal performance and recovery. Made with premium Confitone material for maximum comfort and support.',
    specifications: {
      material: 'Confitone™ Premium Blend (80% Nylon, 20% Spandex)',
      compressionLevel: 'Medical Grade 20-30 mmHg',
      careInstructions: 'Machine wash cold, tumble dry low'
    },
    isBestSeller: true
  },
  {
    id: 'sleeve-navy-2',
    name: 'Athletic Compression Sleeve',
    category: 'Sleeves',
    price: 29.99,
    rating: 4.7,
    reviewCount: 298,
    image: 'https://images.unsplash.com/photo-1595528870853-1277acbfe9ed',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Navy', 'Black', 'Purple', 'Rose'],
    description: 'Engineered for athletes seeking enhanced performance and faster recovery times.',
    specifications: {
      material: 'Confitone™ Premium Blend (80% Nylon, 20% Spandex)',
      compressionLevel: 'Medical Grade 20-30 mmHg',
      careInstructions: 'Machine wash cold, tumble dry low'
    },
    isBestSeller: false
  },
  {
    id: 'sleeve-purple-3',
    name: 'Pro Performance Sleeve',
    category: 'Sleeves',
    price: 32.99,
    rating: 4.9,
    reviewCount: 412,
    image: 'https://images.unsplash.com/photo-1645434927310-388e4592abd9',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Purple', 'Black', 'Navy', 'Rose'],
    description: 'Our most advanced sleeve with superior compression and moisture-wicking technology.',
    specifications: {
      material: 'Confitone™ Premium Blend (80% Nylon, 20% Spandex)',
      compressionLevel: 'Medical Grade 20-30 mmHg',
      careInstructions: 'Machine wash cold, tumble dry low'
    },
    isBestSeller: true
  },
  {
    id: 'sleeve-rose-4',
    name: 'Comfort Compression Sleeve',
    category: 'Sleeves',
    price: 29.99,
    rating: 4.6,
    reviewCount: 267,
    image: 'https://images.unsplash.com/photo-1617127128191-bbbb6d4ada64',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Rose', 'Black', 'Navy', 'Purple'],
    description: 'All-day comfort with effective compression for everyday wear.',
    specifications: {
      material: 'Confitone™ Premium Blend (80% Nylon, 20% Spandex)',
      compressionLevel: 'Medical Grade 20-30 mmHg',
      careInstructions: 'Machine wash cold, tumble dry low'
    },
    isBestSeller: false
  },
  // Compression Waistbands
  {
    id: 'waistband-black-1',
    name: 'Premium Compression Waistband',
    category: 'Waistbands',
    price: 34.99,
    rating: 4.8,
    reviewCount: 389,
    image: 'https://images.unsplash.com/photo-1454957292959-303e248dfe68',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Black', 'Navy', 'Purple', 'Rose'],
    description: 'Targeted compression for core support and improved posture. See results in 30-45 days.',
    specifications: {
      material: 'Confitone™ Premium Blend (80% Nylon, 20% Spandex)',
      compressionLevel: 'Medical Grade 15-25 mmHg',
      careInstructions: 'Machine wash cold, tumble dry low'
    },
    isBestSeller: true
  },
  {
    id: 'waistband-navy-2',
    name: 'Core Support Waistband',
    category: 'Waistbands',
    price: 34.99,
    rating: 4.7,
    reviewCount: 301,
    image: 'https://images.unsplash.com/photo-1646909876562-9a00dab98e65',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Navy', 'Black', 'Purple', 'Rose'],
    description: 'Enhanced core stability with breathable Confitone material.',
    specifications: {
      material: 'Confitone™ Premium Blend (80% Nylon, 20% Spandex)',
      compressionLevel: 'Medical Grade 15-25 mmHg',
      careInstructions: 'Machine wash cold, tumble dry low'
    },
    isBestSeller: false
  },
  {
    id: 'waistband-purple-3',
    name: 'Pro Core Compression',
    category: 'Waistbands',
    price: 37.99,
    rating: 4.9,
    reviewCount: 445,
    image: 'https://images.unsplash.com/photo-1597586309204-ab40c927296d',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Purple', 'Black', 'Navy', 'Rose'],
    description: 'Maximum support for intense workouts and everyday activities.',
    specifications: {
      material: 'Confitone™ Premium Blend (80% Nylon, 20% Spandex)',
      compressionLevel: 'Medical Grade 15-25 mmHg',
      careInstructions: 'Machine wash cold, tumble dry low'
    },
    isBestSeller: true
  },
  {
    id: 'waistband-rose-4',
    name: 'Comfort Core Waistband',
    category: 'Waistbands',
    price: 34.99,
    rating: 4.6,
    reviewCount: 278,
    image: 'https://images.unsplash.com/photo-1641833278434-50f92b93d65a',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Rose', 'Black', 'Navy', 'Purple'],
    description: 'Gentle compression for all-day comfort and support.',
    specifications: {
      material: 'Confitone™ Premium Blend (80% Nylon, 20% Spandex)',
      compressionLevel: 'Medical Grade 15-25 mmHg',
      careInstructions: 'Machine wash cold, tumble dry low'
    },
    isBestSeller: false
  },
  // Bundles
  {
    id: 'bundle-complete-1',
    name: 'Complete Performance Bundle',
    category: 'Bundles',
    price: 54.99,
    originalPrice: 64.98,
    rating: 4.9,
    reviewCount: 512,
    image: 'https://images.unsplash.com/photo-1685045745260-cd6c01b3c4de',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Black', 'Navy', 'Purple', 'Rose'],
    description: 'Save 20%! Premium Sleeve + Waistband combo for complete body support.',
    specifications: {
      material: 'Confitone™ Premium Blend (80% Nylon, 20% Spandex)',
      compressionLevel: 'Medical Grade',
      careInstructions: 'Machine wash cold, tumble dry low'
    },
    isBestSeller: true,
    isBundle: true
  },
  {
    id: 'bundle-starter-2',
    name: 'Starter Compression Bundle',
    category: 'Bundles',
    price: 52.99,
    originalPrice: 64.98,
    rating: 4.8,
    reviewCount: 387,
    image: 'https://images.unsplash.com/photo-1595528870853-1277acbfe9ed',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Navy', 'Black', 'Purple', 'Rose'],
    description: 'Perfect starter kit with our bestselling sleeve and waistband.',
    specifications: {
      material: 'Confitone™ Premium Blend (80% Nylon, 20% Spandex)',
      compressionLevel: 'Medical Grade',
      careInstructions: 'Machine wash cold, tumble dry low'
    },
    isBestSeller: true,
    isBundle: true
  },
  {
    id: 'bundle-pro-3',
    name: 'Pro Athlete Bundle',
    category: 'Bundles',
    price: 59.99,
    originalPrice: 70.98,
    rating: 5.0,
    reviewCount: 623,
    image: 'https://images.unsplash.com/photo-1645434927310-388e4592abd9',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Purple', 'Black', 'Navy', 'Rose'],
    description: 'Premium bundle for serious athletes. Our best-performing products combined.',
    specifications: {
      material: 'Confitone™ Premium Blend (80% Nylon, 20% Spandex)',
      compressionLevel: 'Medical Grade',
      careInstructions: 'Machine wash cold, tumble dry low'
    },
    isBestSeller: true,
    isBundle: true
  },
  {
    id: 'bundle-comfort-4',
    name: 'Comfort Essentials Bundle',
    category: 'Bundles',
    price: 54.99,
    originalPrice: 64.98,
    rating: 4.7,
    reviewCount: 298,
    image: 'https://images.unsplash.com/photo-1617127128191-bbbb6d4ada64',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: ['Rose', 'Black', 'Navy', 'Purple'],
    description: 'Everyday comfort bundle for all-day wear and support.',
    specifications: {
      material: 'Confitone™ Premium Blend (80% Nylon, 20% Spandex)',
      compressionLevel: 'Medical Grade',
      careInstructions: 'Machine wash cold, tumble dry low'
    },
    isBestSeller: false,
    isBundle: true
  }
];

export const testimonials = [
  {
    id: 1,
    name: 'Sarah Mitchell',
    result: 'Lost 2 inches in 30 days',
    quote: 'The compression works exactly as advertised. I noticed visible results in just one month and my posture has improved dramatically!',
    rating: 5,
    image: 'https://images.unsplash.com/photo-1646909876562-9a00dab98e65'
  },
  {
    id: 2,
    name: 'James Chen',
    result: 'Improved posture and confidence',
    quote: 'After years of back pain, the Confitone waistband has been a game-changer. I feel more confident and pain-free.',
    rating: 5,
    image: 'https://images.unsplash.com/photo-1597586309204-ab40c927296d'
  },
  {
    id: 3,
    name: 'Emily Rodriguez',
    result: 'Visible results in 45 days',
    quote: 'I was skeptical at first, but the premium Confitone material really delivers. Worth every penny!',
    rating: 5,
    image: 'https://images.unsplash.com/photo-1646909876562-9a00dab98e65'
  },
  {
    id: 4,
    name: 'Michael Thompson',
    result: 'Enhanced athletic performance',
    quote: 'As an athlete, recovery time is crucial. These compression sleeves have cut my recovery time in half.',
    rating: 5,
    image: 'https://images.unsplash.com/photo-1597586309204-ab40c927296d'
  },
  {
    id: 5,
    name: 'Lisa Anderson',
    result: 'Better circulation and comfort',
    quote: 'I wear mine all day at work. The comfort level is unmatched and my legs feel energized even after long hours.',
    rating: 5,
    image: 'https://images.unsplash.com/photo-1646909876562-9a00dab98e65'
  },
  {
    id: 6,
    name: 'David Park',
    result: 'Reduced swelling significantly',
    quote: 'The 45-day guarantee convinced me to try, and I\'m so glad I did. My swelling is almost completely gone!',
    rating: 5,
    image: 'https://images.unsplash.com/photo-1597586309204-ab40c927296d'
  },
  {
    id: 7,
    name: 'Jessica Williams',
    result: 'Core strength improved',
    quote: 'The waistband provides amazing support during workouts. I can feel my core getting stronger every day.',
    rating: 5,
    image: 'https://images.unsplash.com/photo-1646909876562-9a00dab98e65'
  },
  {
    id: 8,
    name: 'Robert Johnson',
    result: 'Post-surgery recovery accelerated',
    quote: 'My doctor recommended compression wear for recovery. Confitone exceeded all expectations. Highly recommend!',
    rating: 5,
    image: 'https://images.unsplash.com/photo-1597586309204-ab40c927296d'
  }
];
