
import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, CheckCircle, Star } from 'lucide-react';

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center bg-gradient-to-br from-white via-white to-[#e0faee] overflow-hidden py-20 lg:py-0">
      {/* Background Subtle Gradients */}
      <div className="absolute top-0 right-0 -translate-y-1/4 translate-x-1/4 w-[500px] h-[500px] bg-[#59c68b]/10 rounded-full blur-[120px] opacity-60 pointer-events-none" />
      <div className="absolute bottom-0 left-0 translate-y-1/4 -translate-x-1/4 w-[400px] h-[400px] bg-[#D4C5B9]/20 rounded-full blur-[100px] opacity-60 pointer-events-none" />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-20 items-center">
          
          {/* Text Content Column - Left */}
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="flex flex-col space-y-8 text-center md:text-left"
          >
            {/* Trust Badge */}
            <div className="flex justify-center md:justify-start">
              <div className="inline-flex items-center space-x-2 bg-white/80 border border-green-100 rounded-full px-4 py-2 backdrop-blur-sm shadow-sm">
                <div className="flex -space-x-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star key={star} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                  ))}
                </div>
                <span className="text-sm text-gray-700 font-medium">Rated 4.9/5 by 12,000+ Women</span>
              </div>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-gray-900 leading-[1.15] tracking-tight">
              The #1 <span className="text-[#59c68b]">Arm Slimming System</span> Trusted by Over <span className="text-[#59c68b]">12,000 Women 50+</span>
            </h1>
            
            <p className="text-xl text-gray-600 max-w-2xl mx-auto md:mx-0 leading-relaxed font-light">
              Get Rid of Flabby Arms in Just 20 Minutes a Day - Feel Confident in Sleeveless Tops Again.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start w-full sm:w-auto">
              <Link 
                to="/products" 
                className="inline-flex items-center justify-center px-8 py-4 bg-[#59c68b] text-white font-bold text-lg rounded-xl hover:bg-[#4ab07a] transition-all duration-300 shadow-lg shadow-[#59c68b]/20 hover:shadow-[#59c68b]/40 hover:scale-105 group"
              >
                Shop Now
                <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link 
                to="/about" 
                className="inline-flex items-center justify-center px-8 py-4 bg-white/90 border border-green-100 text-gray-700 font-semibold text-lg rounded-xl hover:bg-white transition-all duration-300 hover:scale-105 shadow-sm"
              >
                Learn More
              </Link>
            </div>

            <div className="pt-4 flex flex-wrap justify-center md:justify-start gap-4 lg:gap-8 text-sm text-gray-600 font-medium">
              <div className="flex items-center">
                <CheckCircle className="w-5 h-5 text-[#59c68b] mr-2" />
                <span>Doctor Recommended</span>
              </div>
              <div className="flex items-center">
                <CheckCircle className="w-5 h-5 text-[#59c68b] mr-2" />
                <span>30-Day Guarantee</span>
              </div>
              <div className="flex items-center">
                <CheckCircle className="w-5 h-5 text-[#59c68b] mr-2" />
                <span>Fast Shipping</span>
              </div>
            </div>
          </motion.div>

          {/* Image Column - Right */}
          <motion.div 
            initial={{ opacity: 0, x: 50, scale: 0.95 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="relative rounded-3xl overflow-hidden shadow-2xl border border-green-100 group aspect-[4/5] md:aspect-square max-w-lg mx-auto md:max-w-none">
              <div className="absolute inset-0 bg-gradient-to-t from-gray-900/40 to-transparent z-10 pointer-events-none" />
              <img 
                src="https://horizons-cdn.hostinger.com/39e3b2ff-3d9a-4c80-b016-dd813e6b8ced/gempages_566140998057460946-60942c31-849e-40bc-a202-8d051710ffe9-nYg8a.webp" 
                alt="Happy customers using Confitone" 
                className="w-full h-full object-cover transform transition-transform duration-700 group-hover:scale-110"
              />
              
              {/* Floating Element - Social Proof */}
              <motion.div 
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 1, duration: 0.5 }}
                className="absolute bottom-6 left-6 right-6 z-20 bg-white/95 backdrop-blur-md p-4 rounded-2xl shadow-xl border border-white/20"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-900 font-bold text-sm">Join the Community</p>
                    <p className="text-gray-600 text-xs">Transform your life today</p>
                  </div>
                  <div className="flex items-center">
                    <div className="flex -space-x-2 mr-3">
                      {[1,2,3].map(i => (
                        <div key={i} className="w-8 h-8 rounded-full border-2 border-white bg-green-50 flex items-center justify-center text-[10px] text-gray-500 font-bold overflow-hidden">
                          {/* Placeholder avatars since we don't have separate URLs */}
                           <div className="w-full h-full bg-gray-300" />
                        </div>
                      ))}
                    </div>
                    <span className="text-xs font-bold text-[#59c68b]">+12k</span>
                  </div>
                </div>
              </motion.div>
            </div>

            {/* Decorative background element behind image */}
            <div className="absolute -z-10 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-[#59c68b]/20 rounded-full blur-[80px] opacity-60 pointer-events-none" />
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
