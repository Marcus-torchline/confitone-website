
import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Instagram, Twitter, Mail, Phone, MapPin } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-[#59c68b] text-white border-t border-white/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand Info */}
          <div className="space-y-4">
            <Link to="/" className="inline-block"> {/* Ensure logo is clickable */}
              <img
                src="https://horizons-cdn.hostinger.com/39e3b2ff-3d9a-4c80-b016-dd813e6b8ced/confitone-white-logo-tliBS.png"
                alt="Confitone Logo"
                className="max-w-[150px] h-auto"
              />
            </Link>
            <p className="text-sm text-white/90">
              The one and only true Confitone brand. Premium compression wear with new management and improved quality.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-white hover:text-white/80 transition-colors duration-200">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="text-white hover:text-white/80 transition-colors duration-200">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="text-white hover:text-white/80 transition-colors duration-200">
                <Twitter className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-semibold text-lg mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/products" className="text-white/90 hover:text-white transition-colors duration-200">
                  Shop Products
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-white/90 hover:text-white transition-colors duration-200">
                  About Us
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-white/90 hover:text-white transition-colors duration-200">
                  Contact
                </Link>
              </li>
              <li>
                <Link to="/cart" className="text-white/90 hover:text-white transition-colors duration-200">
                  Shopping Cart
                </Link>
              </li>
            </ul>
          </div>

          {/* Customer Service */}
          <div>
            <h3 className="text-white font-semibold text-lg mb-4">Customer Service</h3>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-white/90 hover:text-white transition-colors duration-200">
                  45-Day Return Policy
                </a>
              </li>
              <li>
                <a href="#" className="text-white/90 hover:text-white transition-colors duration-200">
                  Shipping Information
                </a>
              </li>
              <li>
                <a href="#" className="text-white/90 hover:text-white transition-colors duration-200">
                  Track Your Order
                </a>
              </li>
              <li>
                <a href="#" className="text-white/90 hover:text-white transition-colors duration-200">
                  Size Guide
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-white font-semibold text-lg mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start space-x-2">
                <Mail className="w-5 h-5 mt-0.5 flex-shrink-0 text-white" />
                <span className="text-sm text-white/90">support@confitone.com</span>
              </li>
              <li className="flex items-start space-x-2">
                <Phone className="w-5 h-5 mt-0.5 flex-shrink-0 text-white" />
                <span className="text-sm text-white/90">1-800-CONFITONE</span>
              </li>
              <li className="flex items-start space-x-2">
                <MapPin className="w-5 h-5 mt-0.5 flex-shrink-0 text-white" />
                <span className="text-sm text-white/90">123 Performance Ave, Suite 100<br />Athletic City, AC 12345</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/20 mt-8 pt-8 text-sm text-center text-white/80">
          <p>&copy; {new Date().getFullYear()} Confitone. All rights reserved. Premium compression wear with Confitone™ trademark material.</p>
        </div>
      </div>
    </footer>
  );
};
export default Footer;
