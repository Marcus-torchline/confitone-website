
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { getProducts, getProductQuantities } from '@/api/EcommerceApi';
import ProductCard from '@/components/ProductCard';
import { Loader2 } from 'lucide-react';

const FeaturedProducts = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await getProducts();
        if (response.products) {
          // Get the first 3 products as featured
          const featured = response.products.slice(0, 3);
          
          // Fetch quantities for these products
          const productIds = featured.map(p => p.id);
          const quantitiesResponse = await getProductQuantities({
             fields: 'inventory_quantity',
             product_ids: productIds
          });
          
          const variantQuantityMap = new Map();
          quantitiesResponse.variants.forEach(variant => {
             variantQuantityMap.set(variant.id, variant.inventory_quantity);
          });
          
          const enrichedProducts = featured.map(p => ({
             ...p,
             variants: p.variants.map(v => ({
                ...v,
                inventory_quantity: variantQuantityMap.get(v.id) ?? v.inventory_quantity
             }))
          }));

          setProducts(enrichedProducts);
        }
      } catch (error) {
        console.error("Failed to fetch featured products", error);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  return (
    <section className="py-16 bg-gradient-to-b from-[#f0fdf4] to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Bestselling Products
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Discover our most popular compression wear, trusted by thousands of satisfied customers.
          </p>
        </motion.div>

        {loading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-12 h-12 text-[#59c68b] animate-spin" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {products.map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="h-full"
              >
                <ProductCard product={product} />
              </motion.div>
            ))}
          </div>
        )}

        <div className="text-center mt-12">
          <Link
            to="/products"
            className="inline-block px-8 py-3 bg-[#59c68b] text-white font-semibold rounded-lg hover:bg-[#4ab07a] transition-all duration-300 hover:shadow-lg hover:scale-105 shadow-md shadow-green-200"
          >
            View All Products
          </Link>
        </div>
      </div>
    </section>
  );
};

export default FeaturedProducts;
