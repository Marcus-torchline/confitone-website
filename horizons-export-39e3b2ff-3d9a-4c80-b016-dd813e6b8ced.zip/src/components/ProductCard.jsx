
import React, { useMemo, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ShoppingCart } from 'lucide-react';
import { useCart } from '@/hooks/useCart';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';

const placeholderImage = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjMwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjMzc0MTUxIi8+CiAgPHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxOCIgZmlsbD0iIzlDQTNBRiIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk5vIEltYWdlPC90ZXh0Pgo8L3N2Zz4K";

const ProductCard = ({ product }) => {
  const { addToCart } = useCart();
  const { toast } = useToast();
  const navigate = useNavigate();

  // Handle both API product structure and potential static data legacy structure
  const displayVariant = useMemo(() => product.variants && product.variants.length > 0 ? product.variants[0] : null, [product]);
  const hasSale = useMemo(() => displayVariant && displayVariant.sale_price_in_cents !== null, [displayVariant]);
  const displayPrice = useMemo(() => displayVariant ? (hasSale ? displayVariant.sale_price_formatted : displayVariant.price_formatted) : '$0.00', [displayVariant, hasSale]);
  const originalPrice = useMemo(() => displayVariant && hasSale ? displayVariant.price_formatted : null, [displayVariant, hasSale]);

  const imageSrc = product.image || product.image_url || placeholderImage;

  const handleAddToCart = useCallback(async (e) => {
    e.preventDefault();
    e.stopPropagation();

    // If product has multiple variants or complex options, go to detail page
    if (product.variants && product.variants.length > 1) {
      navigate(`/product/${product.id}`);
      return;
    }

    if (!displayVariant) {
       navigate(`/product/${product.id}`);
       return;
    }

    try {
      await addToCart(product, displayVariant, 1, displayVariant.inventory_quantity);
      toast({
        title: "Added to Cart!",
        description: `${product.title} has been added to your cart.`,
      });
    } catch (error) {
      toast({
        title: "Error adding to cart",
        description: error.message,
        variant: "destructive"
      });
    }
  }, [product, displayVariant, addToCart, toast, navigate]);

  return (
    <Link to={`/product/${product.id}`} className="block h-full">
      <motion.div
        whileHover={{ y: -8 }}
        transition={{ duration: 0.3 }}
        className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition-shadow duration-300 h-full flex flex-col group border border-gray-100 hover:border-[#59c68b]/30"
      >
        <div className="relative aspect-square overflow-hidden bg-[#f0fdf4]">
          <img
            src={imageSrc}
            alt={product.title || product.name}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          />
          {product.ribbon_text && (
            <div className="absolute top-4 right-4 bg-[#59c68b] text-white px-3 py-1 rounded-full text-sm font-semibold shadow-md">
              {product.ribbon_text}
            </div>
          )}
        </div>
        
        <div className="p-6 flex flex-col flex-grow bg-white">
          <h3 className="text-lg font-semibold text-gray-900 mb-2 line-clamp-2">
            {product.title || product.name}
          </h3>
          
          <div className="mb-4">
             {originalPrice ? (
              <div className="flex items-center space-x-2">
                <span className="text-2xl font-bold text-[#59c68b]">
                  {displayPrice}
                </span>
                <span className="text-lg text-gray-400 line-through">
                  {originalPrice}
                </span>
              </div>
            ) : (
              <span className="text-2xl font-bold text-gray-900">
                {displayPrice}
              </span>
            )}
          </div>
          
          <Button
            onClick={handleAddToCart}
            className="mt-auto w-full bg-[#59c68b] text-white py-6 rounded-lg font-semibold hover:bg-[#4ab07a] transition-all duration-300 hover:shadow-lg hover:scale-105 flex items-center justify-center space-x-2"
          >
            <ShoppingCart className="w-5 h-5 mr-2" />
            <span>Add to Cart</span>
          </Button>
        </div>
      </motion.div>
    </Link>
  );
};

export default ProductCard;
