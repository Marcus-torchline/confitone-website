
import React from 'react';
import { motion } from 'framer-motion';
import { Shield, Award, Truck } from 'lucide-react';

const TrustBadges = () => {
  const badges = [
    {
      icon: Shield,
      title: '45-Day Return Policy',
      description: 'Risk-free satisfaction guarantee'
    },
    {
      icon: Award,
      title: 'Premium Confitone Material',
      description: 'Trademark quality you can trust'
    },
    {
      icon: Truck,
      title: 'Fast Shipping with Tracking',
      description: 'Improved tracking system'
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {badges.map((badge, index) => (
            <motion.div
              key={badge.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="flex flex-col items-center text-center p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow duration-300 border border-green-100"
              style={{ background: 'linear-gradient(135deg, rgba(255,255,255,1) 0%, rgba(240,253,244,1) 100%)' }}
            >
              <div className="w-16 h-16 bg-[#59c68b]/10 rounded-full flex items-center justify-center mb-4 text-[#59c68b]">
                <badge.icon className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                {badge.title}
              </h3>
              <p className="text-gray-600 text-sm">
                {badge.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TrustBadges;
