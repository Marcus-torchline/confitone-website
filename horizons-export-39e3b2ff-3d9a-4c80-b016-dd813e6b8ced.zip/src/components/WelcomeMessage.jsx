
import React from 'react';
import { motion } from 'framer-motion';

const WelcomeMessage = () => {
  return (
    <motion.p
      className='text-sm text-gray-700 leading-5 w-full bg-[#59c68b]/10 p-2 rounded-md border border-[#59c68b]/20'
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5, delay: 0.8 }}
    >
      Write in the chat what you want to create.
    </motion.p>
  );
};

export default WelcomeMessage;
