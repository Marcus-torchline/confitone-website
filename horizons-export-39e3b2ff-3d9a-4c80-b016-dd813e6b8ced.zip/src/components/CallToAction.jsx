
import React from 'react';
import { motion } from 'framer-motion';

const CallToAction = () => {
  return (
    <motion.h1
      className='text-xl font-bold text-gray-900 leading-8 w-full bg-gradient-to-r from-[#59c68b]/20 to-white p-4 rounded-lg text-center border border-[#59c68b]/30'
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5, delay: 0.5 }}
    >
      Let's turn your ideas into reality
    </motion.h1>
  );
};

export default CallToAction;
