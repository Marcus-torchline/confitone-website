
import React, { useState, useEffect, useRef } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ShoppingCart as ShoppingCartIcon, Menu, X } from 'lucide-react';
import { useCart } from '@/hooks/useCart';
import { useToast } from '@/components/ui/use-toast';
import { motion, AnimatePresence } from 'framer-motion';
import ShoppingCart from '@/components/ShoppingCart';
import Logo from '@/components/Logo';

const Header = () => {
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { getCartCount } = useCart();
  const location = useLocation();
  const { toast } = useToast();
  const cartCount = getCartCount();
  const menuRef = useRef(null);

  // Close menu when route changes
  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setIsMenuOpen(false);
      }
    };

    if (isMenuOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isMenuOpen]);

  const isActive = (path) => location.pathname === path;

  const handleLiveChat = (e) => {
    e.preventDefault();
    toast({
      title: "Live Chat",
      description: "Live Chat feature is coming soon! 🚀",
    });
    setIsMenuOpen(false);
  };

  const handleTracking = (e) => {
    e.preventDefault();
    toast({
      title: "Order Tracking",
      description: "Order tracking feature is coming soon! 🚀",
    });
    setIsMenuOpen(false);
  };

  const linkStyles = "text-white font-medium hover:text-white/80 hover:underline transition-all duration-200 text-sm lg:text-base whitespace-nowrap";
  const activeLinkStyles = "text-white font-bold underline decoration-2 underline-offset-4";
  const mobileLinkStyles = "block py-4 px-6 text-white hover:bg-white/10 text-lg border-b border-white/10 transition-colors";

  // Navigation Arrays
  const desktopLeftLinks = [
    { type: 'link', path: '/login', label: 'Customer Portal' },
    { type: 'button', action: handleLiveChat, label: 'Live Chat' },
    { type: 'button', action: handleTracking, label: 'Tracking' },
  ];

  const desktopRightLinks = [
    { path: '/', label: 'Home' },
    { path: '/products', label: 'Products' },
    { path: '/about', label: 'About' },
    { path: '/contact', label: 'Contact' },
  ];

  // Mobile visible links (outside menu)
  const mobileVisibleLinks = [
    { path: '/', label: 'Home' },
    { path: '/products', label: 'Products' },
  ];

  // Mobile menu links (inside dropdown)
  const mobileMenuLinks = [
    { type: 'link', path: '/about', label: 'About' },
    { type: 'link', path: '/contact', label: 'Contact' },
    { type: 'link', path: '/login', label: 'Customer Portal' },
    { type: 'button', action: handleLiveChat, label: 'Live Chat' },
    { type: 'button', action: handleTracking, label: 'Tracking' },
  ];

  return (
    <>
      <header className="bg-[#59c68b] shadow-md sticky top-0 z-50" ref={menuRef}>
        <nav className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="h-16 flex items-center justify-between relative">
            
            {/* ---------------- DESKTOP LAYOUT (md:flex) ---------------- */}

            {/* Left Section (Desktop) */}
            <div className="hidden md:flex items-center gap-6 z-10 w-1/3 justify-start">
              {desktopLeftLinks.map((item, idx) => (
                 item.type === 'link' ? (
                   <Link key={idx} to={item.path} className={linkStyles}>{item.label}</Link>
                 ) : (
                   <button key={idx} onClick={item.action} className={`${linkStyles} bg-transparent border-none cursor-pointer`}>
                     {item.label}
                   </button>
                 )
              ))}
            </div>

            {/* Center Section (Logo - Desktop Absolute Center) */}
            <div className="hidden md:block absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 z-20">
               <Logo />
            </div>

            {/* Right Section (Desktop) */}
            <div className="hidden md:flex items-center gap-6 z-10 w-1/3 justify-end">
              {desktopRightLinks.map(link => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`${linkStyles} ${isActive(link.path) ? activeLinkStyles : ''}`}
                >
                  {link.label}
                </Link>
              ))}
              <button
                onClick={() => setIsCartOpen(true)}
                className="relative p-2 text-white hover:text-white/80 transition-colors duration-200"
                aria-label="Shopping Cart"
              >
                <ShoppingCartIcon className="w-6 h-6" />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-white text-[#59c68b] text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center shadow-sm">
                    {cartCount}
                  </span>
                )}
              </button>
            </div>

            {/* ---------------- MOBILE LAYOUT (md:hidden) ---------------- */}
            
            <div className="flex md:hidden w-full items-center justify-between">
                {/* Left Side: Mobile Visible Links */}
                <div className="flex items-center gap-3 z-10 flex-1">
                   {mobileVisibleLinks.map(link => (
                    <Link
                      key={link.path}
                      to={link.path}
                      className={`${linkStyles} text-xs sm:text-sm font-semibold`}
                    >
                      {link.label}
                    </Link>
                  ))}
                </div>

                {/* Center: Logo (Absolute Center for Mobile too to ensure alignment) */}
                <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 z-0">
                  <Logo />
                </div>

                {/* Right Side: Cart & Menu */}
                <div className="flex items-center gap-2 z-10 flex-1 justify-end">
                  <button
                    onClick={() => setIsCartOpen(true)}
                    className="relative p-2 text-white hover:text-white/80 transition-colors duration-200"
                    aria-label="Shopping Cart"
                  >
                    <ShoppingCartIcon className="w-5 h-5" />
                    {cartCount > 0 && (
                      <span className="absolute -top-1 -right-1 bg-white text-[#59c68b] text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center shadow-sm">
                        {cartCount}
                      </span>
                    )}
                  </button>
                  <button
                    onClick={() => setIsMenuOpen(!isMenuOpen)}
                    className="p-2 text-white hover:text-white/80 transition-colors duration-200"
                    aria-label="Menu"
                  >
                    {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
                  </button>
                </div>
            </div>
          </div>

          {/* Mobile Dropdown Menu */}
          <AnimatePresence>
            {isMenuOpen && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3, ease: "easeInOut" }}
                className="md:hidden overflow-hidden bg-[#59c68b] border-t border-white/20 absolute left-0 right-0 top-16 shadow-xl rounded-b-xl z-50"
              >
                <div className="flex flex-col py-2 max-h-[80vh] overflow-y-auto">
                  {mobileMenuLinks.map((item, idx) => (
                     item.type === 'link' ? (
                       <Link 
                        key={idx} 
                        to={item.path} 
                        className={mobileLinkStyles}
                        onClick={() => setIsMenuOpen(false)}
                       >
                         {item.label}
                       </Link>
                     ) : (
                       <button 
                        key={idx} 
                        onClick={item.action} 
                        className={`${mobileLinkStyles} text-left w-full bg-transparent`}
                       >
                         {item.label}
                       </button>
                     )
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </nav>
      </header>
      
      <ShoppingCart isCartOpen={isCartOpen} setIsCartOpen={setIsCartOpen} />
    </>
  );
};

export default Header;
