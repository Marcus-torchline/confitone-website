
import React from 'react';
import { motion } from 'framer-motion';
import { Tag, Gift, Shield } from 'lucide-react';
import { Link } from 'react-router-dom';

const PromotionsSection = () => {
  const promotions = [
    {
      icon: Gift,
      title: 'New Year Bundle',
      description: 'Premium Sleeve + Waistband combo',
      discount: '20% OFF',
      cta: 'Shop Now',
      link: '/products'
    },
    {
      icon: Tag,
      title: 'First Time Customer',
      description: 'Use code at checkout',
      discount: '15% OFF',
      code: 'WELCOME15',
      cta: 'Shop Now',
      link: '/products'
    },
    {
      icon: Shield,
      title: '45-Day Guarantee',
      description: 'Risk-free trial with full return policy',
      discount: 'WORRY-FREE',
      cta: 'Learn More',
      link: '/about'
    }
  ];

  return (
    <section className="py-16 bg-gradient-to-b from-white to-[#f0fdf4]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Special Offers
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Take advantage of our exclusive deals and save on premium Confitone products.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {promotions.map((promo, index) => (
            <motion.div
              key={promo.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="rounded-xl p-8 text-center hover:shadow-lg transition-all duration-300 border border-[#59c68b]/20"
              style={{ background: 'rgba(89, 198, 139, 0.08)' }}
            >
              <div className="w-16 h-16 bg-[#59c68b] rounded-full flex items-center justify-center mx-auto mb-6 shadow-md shadow-green-200">
                <promo.icon className="w-8 h-8 text-white" />
              </div>
              
              <h3 className="text-2xl font-bold text-gray-900 mb-2">
                {promo.title}
              </h3>
              
              <p className="text-gray-600 mb-4">
                {promo.description}
              </p>
              
              <div className="text-3xl font-bold text-[#59c68b] mb-2">
                {promo.discount}
              </div>
              
              {promo.code && (
                <div className="bg-white/80 rounded-lg px-4 py-2 mb-4 inline-block shadow-sm border border-green-100">
                  <code className="text-lg font-mono font-semibold text-gray-900">
                    {promo.code}
                  </code>
                </div>
              )}
              
              <Link
                to={promo.link}
                className="inline-block px-6 py-3 bg-[#59c68b] text-white font-semibold rounded-lg hover:bg-[#4ab07a] transition-all duration-300 hover:shadow-lg hover:scale-105 mt-4"
              >
                {promo.cta}
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PromotionsSection;
