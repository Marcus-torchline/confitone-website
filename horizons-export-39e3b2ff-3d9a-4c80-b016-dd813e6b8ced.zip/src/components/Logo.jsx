import React from 'react';
import { Link } from 'react-router-dom';
const Logo = ({
  className = ''
}) => {
  return <Link to="/" className={`group ${className}`}>
      <img src="https://horizons-cdn.hostinger.com/39e3b2ff-3d9a-4c80-b016-dd813e6b8ced/confitone-white-logo-tliBS.png" alt="CONFITONE Logo" className="h-10 md:h-12 object-contain transition-transform duration-300 group-hover:scale-105" />
    </Link>;
};
export default Logo;