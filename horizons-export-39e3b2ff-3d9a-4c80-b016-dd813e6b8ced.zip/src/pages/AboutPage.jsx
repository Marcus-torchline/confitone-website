
import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Award, Shield, TrendingUp, Users, Star, CheckCircle } from 'lucide-react';

const AboutPage = () => {
  const features = [
    {
      icon: Award,
      title: 'Confitone™ Trademark Material',
      description: 'Our proprietary blend ensures medical-grade compression with all-day comfort.'
    },
    {
      icon: Shield,
      title: '45-Day Return Policy',
      description: 'Risk-free satisfaction guarantee. Not happy? Get a full refund, no questions asked.'
    },
    {
      icon: TrendingUp,
      title: 'Proven Results',
      description: 'See visible improvements in 30-45 days with consistent use.'
    },
    {
      icon: Users,
      title: 'Expert Customer Service',
      description: 'Our dedicated team is here to help you every step of the way.'
    }
  ];

  const metrics = [
    { value: '50,000+', label: 'Happy Customers' },
    { value: '4.8/5', label: 'Average Rating' },
    { value: '98%', label: 'Satisfaction Rate' },
    { value: '45 Days', label: 'Return Window' }
  ];

  return (
    <>
      <Helmet>
        <title>About Confitone - Premium Compression Wear</title>
        <meta
          name="description"
          content="Learn about Confitone's new management, premium quality products, and our commitment to excellence in compression wear."
        />
      </Helmet>

      <div className="min-h-screen bg-white">
        {/* Hero Section */}
        <div className="relative bg-gradient-to-br from-primary to-primary-700 py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center"
            >
              <h1 className="text-5xl font-bold text-white mb-6">
                The One and Only True Confitone Brand
              </h1>
              <p className="text-xl text-white/90 max-w-3xl mx-auto">
                Experience premium compression wear with new management and exceptional quality that sets us apart.
              </p>
            </motion.div>
          </div>
        </div>

        {/* Brand Story */}
        <div className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="max-w-4xl mx-auto text-center"
            >
              <h2 className="text-4xl font-bold text-gray-900 mb-6">
                New and Improved Confitone
              </h2>
              <p className="text-lg text-gray-700 mb-6 leading-relaxed">
                Under new management, Confitone has undergone a complete transformation. We've enhanced our proprietary Confitone™ material, improved our customer service, and implemented state-of-the-art tracking systems to ensure your complete satisfaction.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed">
                Our commitment to quality and customer care has never been stronger. Every product is crafted with precision using our trademark Confitone material, designed to deliver medical-grade compression with unparalleled comfort.
              </p>
            </motion.div>
          </div>
        </div>

        {/* Trust Metrics */}
        <div className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {metrics.map((metric, index) => (
                <motion.div
                  key={metric.label}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="text-center"
                >
                  <div className="text-4xl font-bold text-primary mb-2">
                    {metric.value}
                  </div>
                  <div className="text-gray-600 font-medium">
                    {metric.label}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* Key Features */}
        <div className="py-16 bg-gray-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <h2 className="text-4xl font-bold text-gray-900 mb-4">
                Why Choose Confitone
              </h2>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                We're committed to providing the highest quality compression wear backed by exceptional service.
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {features.map((feature, index) => (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="bg-white rounded-xl shadow-md p-6 text-center hover:shadow-lg transition-shadow duration-300"
                >
                  <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <feature.icon className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600">
                    {feature.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* What Sets Us Apart */}
        <div className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <h2 className="text-4xl font-bold text-gray-900 mb-6">
                  What Sets Us Apart
                </h2>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-1">Premium Confitone™ Material</h3>
                      <p className="text-gray-600">Our proprietary blend provides medical-grade compression that lasts.</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-1">Improved Tracking System</h3>
                      <p className="text-gray-600">Know exactly where your order is with our enhanced tracking technology.</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-1">New Management Excellence</h3>
                      <p className="text-gray-600">Fresh leadership committed to quality and customer satisfaction.</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <CheckCircle className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-1">Visible Results in 30-45 Days</h3>
                      <p className="text-gray-600">Our customers see real, measurable improvements with consistent use.</p>
                    </div>
                  </div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="relative"
              >
                <img
                  src="https://images.unsplash.com/photo-1646909876562-9a00dab98e65"
                  alt="Confitone Quality"
                  className="rounded-2xl shadow-2xl"
                />
              </motion.div>
            </div>
          </div>
        </div>

        {/* Customer Testimonials Summary */}
        <div className="py-16 bg-primary">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <Star className="w-16 h-16 text-accent mx-auto mb-6 fill-current" />
              <h2 className="text-4xl font-bold text-white mb-4">
                Trusted by Thousands
              </h2>
              <p className="text-xl text-white/90 max-w-3xl mx-auto mb-8">
                Join over 50,000 satisfied customers who have transformed their performance and recovery with Confitone.
              </p>
              <div className="flex justify-center items-center space-x-2 text-white">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-8 h-8 fill-current text-accent" />
                ))}
                <span className="ml-4 text-2xl font-semibold">4.8 / 5.0</span>
              </div>
            </motion.div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="py-16 bg-gray-50">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="text-4xl font-bold text-gray-900 mb-6">
                Experience the Confitone Difference
              </h2>
              <p className="text-lg text-gray-600 mb-8">
                Try our premium compression wear risk-free with our 45-day satisfaction guarantee.
              </p>
              <Link
                to="/products"
                className="inline-block px-8 py-4 bg-primary text-white font-semibold rounded-lg hover:bg-primary-700 transition-all duration-300 hover:shadow-lg hover:scale-105"
              >
                Shop Products
              </Link>
            </motion.div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AboutPage;
