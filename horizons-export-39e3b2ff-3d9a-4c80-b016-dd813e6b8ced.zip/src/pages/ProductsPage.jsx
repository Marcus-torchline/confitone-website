
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { getProducts, getProductQuantities } from '@/api/EcommerceApi';
import ProductCard from '@/components/ProductCard';
import { Loader2 } from 'lucide-react';

const ProductsPage = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [sortBy, setSortBy] = useState('featured');

  const categories = ['All', 'Sleeves', 'Waistbands', 'Bundles'];

  useEffect(() => {
    const fetchAllProducts = async () => {
      try {
        setLoading(true);
        const response = await getProducts();
        
        if (response.products) {
          const productIds = response.products.map(p => p.id);
          const quantitiesResponse = await getProductQuantities({
             fields: 'inventory_quantity',
             product_ids: productIds
          });
          
          const variantQuantityMap = new Map();
          quantitiesResponse.variants.forEach(variant => {
             variantQuantityMap.set(variant.id, variant.inventory_quantity);
          });
          
          const enrichedProducts = response.products.map(p => ({
             ...p,
             variants: p.variants.map(v => ({
                ...v,
                inventory_quantity: variantQuantityMap.get(v.id) ?? v.inventory_quantity
             }))
          }));
          
          setProducts(enrichedProducts);
        }
      } catch (err) {
        setError('Failed to load products. Please try again later.');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchAllProducts();
  }, []);

  // Basic client-side filtering logic to maintain legacy filter UI
  // Note: Real API products might not have 'category' field populated as expected by static data
  // We'll perform a basic text search on title/description if category field is missing
  const filteredProducts = products.filter(product => {
    if (selectedCategory === 'All') return true;
    
    // Check if product has explicit category, otherwise check title
    const categoryMatch = product.category === selectedCategory;
    const titleMatch = product.title.toLowerCase().includes(selectedCategory.toLowerCase().slice(0, -1)); // remove 's'
    
    return categoryMatch || titleMatch;
  });

  const sortedProducts = [...filteredProducts].sort((a, b) => {
    const priceA = a.variants?.[0]?.sale_price_in_cents || a.variants?.[0]?.price_in_cents || 0;
    const priceB = b.variants?.[0]?.sale_price_in_cents || b.variants?.[0]?.price_in_cents || 0;

    switch (sortBy) {
      case 'price-low':
        return priceA - priceB;
      case 'price-high':
        return priceB - priceA;
      case 'newest':
        return b.id.localeCompare(a.id); // Assuming higher ID is newer or string comparison
      default:
        return 0;
    }
  });

  return (
    <>
      <Helmet>
        <title>Shop All Products - Confitone Compression Wear</title>
        <meta
          name="description"
          content="Browse our complete collection of premium compression sleeves, waistbands, and bundle deals. Made with trademark Confitone material for superior performance."
        />
      </Helmet>

      <div className="min-h-screen bg-gray-50">
        {/* Page Header */}
        <div className="bg-white py-12 mb-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="text-4xl font-bold text-gray-900 mb-4">
                Shop All Products
              </h1>
              <p className="text-lg text-gray-600">
                Discover our complete range of premium compression wear
              </p>
            </motion.div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
          {/* Filters and Sorting */}
          <div className="mb-8 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            {/* Category Filter */}
            <div className="flex flex-wrap gap-2">
              {categories.map(category => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-4 py-2 rounded-lg font-medium transition-all duration-300 ${
                    selectedCategory === category
                      ? 'bg-[#59c68b] text-white shadow-md' // Active state: brand green background
                      : 'bg-white text-gray-700 hover:bg-[#a6e0c0]' // Inactive state: white background, hover darker green
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>

            {/* Sort Dropdown */}
            <div className="flex items-center space-x-3">
              <label htmlFor="sort" className="text-gray-700 font-medium">
                Sort by:
              </label>
              <select
                id="sort"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="px-4 py-2 bg-white border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#59c68b] focus:border-transparent text-gray-900"
              >
                <option value="featured">Featured</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
                <option value="newest">Newest</option>
              </select>
            </div>
          </div>

          {loading ? (
             <div className="flex justify-center py-20">
               <Loader2 className="w-16 h-16 text-[#59c68b] animate-spin" />
             </div>
          ) : error ? (
             <div className="text-center py-12 text-red-500">
                <p>{error}</p>
             </div>
          ) : (
            <>
              {/* Products Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {sortedProducts.map((product, index) => (
                  <motion.div
                    key={product.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.05 }}
                    className="h-full"
                  >
                    <ProductCard product={product} />
                  </motion.div>
                ))}
              </div>

              {sortedProducts.length === 0 && (
                <div className="text-center py-12">
                  <p className="text-xl text-gray-600">
                    No products found in this category.
                  </p>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </>
  );
};

export default ProductsPage;
