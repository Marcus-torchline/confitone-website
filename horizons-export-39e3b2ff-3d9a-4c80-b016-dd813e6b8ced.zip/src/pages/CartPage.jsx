
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Trash2, ShoppingBag, Loader2 } from 'lucide-react';
import { useCart } from '@/hooks/useCart';
import { useToast } from '@/components/ui/use-toast';
import { initializeCheckout, formatCurrency } from '@/api/EcommerceApi';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

const CartPage = () => {
  const {
    cartItems,
    removeFromCart,
    updateQuantity,
    getCartNumericTotal,
    clearCart
  } = useCart();
  
  const { toast } = useToast();
  const [itemToRemove, setItemToRemove] = useState(null);
  const [isCheckingOut, setIsCheckingOut] = useState(false);

  const cartTotal = getCartNumericTotal();
  
  // Shipping logic: Free > $100, $5 > $50, else $10
  const shippingCost = cartTotal > 100 ? 0 : (cartTotal > 50 ? 5 : 10);
  const taxAmount = cartTotal * 0.08;
  const finalTotal = cartTotal + shippingCost + taxAmount;

  // Assuming USD for now or taking from first item context
  const currencyInfo = cartItems.length > 0 ? cartItems[0].variant.currency_info : { symbol: '$', decimal_places: 2 };

  const format = (val) => formatCurrency(Math.round(val * 100), currencyInfo);

  const handleRemoveItem = () => {
    if (itemToRemove) {
      removeFromCart(itemToRemove);
      toast({
        title: 'Item removed',
        description: 'Product has been removed from your cart.',
      });
      setItemToRemove(null);
    }
  };

  const handleCheckout = async () => {
    setIsCheckingOut(true);
    try {
      const items = cartItems.map(item => ({
        variant_id: item.variant.id,
        quantity: item.quantity,
      }));

      const successUrl = `${window.location.origin}/success`;
      const cancelUrl = window.location.href;

      const { url } = await initializeCheckout({ items, successUrl, cancelUrl });

      clearCart();
      window.location.href = url;
    } catch (error) {
      console.error(error);
      toast({
        title: 'Checkout Error',
        description: 'There was a problem initializing checkout. Please try again.',
        variant: 'destructive',
      });
      setIsCheckingOut(false);
    }
  };

  if (cartItems.length === 0) {
    return (
      <>
        <Helmet>
          <title>Shopping Cart - Confitone</title>
          <meta name="description" content="Your Confitone shopping cart" />
        </Helmet>

        <div className="min-h-screen bg-gray-50 flex items-center justify-center">
          <div className="text-center">
            <ShoppingBag className="w-24 h-24 text-gray-300 mx-auto mb-6" />
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Your cart is empty</h2>
            <p className="text-gray-600 mb-8">
              Add some premium Confitone products to get started!
            </p>
            <Link
              to="/products"
              className="inline-block px-8 py-3 bg-primary text-white font-semibold rounded-lg hover:bg-primary-700 transition-all duration-300 hover:shadow-lg hover:scale-105"
            >
              Shop Now
            </Link>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>Shopping Cart - Confitone</title>
        <meta name="description" content="Review your Confitone shopping cart and proceed to checkout" />
      </Helmet>

      <div className="min-h-screen bg-gray-50 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-4xl font-bold text-gray-900 mb-8">Shopping Cart</h1>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Cart Items */}
              <div className="lg:col-span-2">
                <div className="bg-white rounded-xl shadow-md overflow-hidden">
                  {cartItems.map((item, index) => (
                    <motion.div
                      key={item.variant.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.1 }}
                      className="p-6 border-b last:border-b-0"
                    >
                      <div className="flex items-center space-x-6">
                        <img
                          src={item.product.image || item.product.image_url || "https://placehold.co/100x100"}
                          alt={item.product.title}
                          className="w-24 h-24 object-cover rounded-lg"
                        />
                        
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold text-gray-900 mb-2">
                            {item.product.title}
                          </h3>
                          <div className="text-sm text-gray-600 space-y-1">
                            <p>{item.variant.title}</p>
                            <p className="text-lg font-bold text-primary">
                              {item.variant.sale_price_formatted || item.variant.price_formatted}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center space-x-4">
                          <div className="flex items-center space-x-2">
                            <button
                              onClick={() => updateQuantity(item.variant.id, item.quantity - 1)}
                              className="w-8 h-8 bg-gray-100 rounded hover:bg-gray-200 transition-colors duration-300 font-semibold text-gray-700"
                            >
                              -
                            </button>
                            <span className="w-12 text-center font-semibold text-gray-900">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => updateQuantity(item.variant.id, item.quantity + 1)}
                              className="w-8 h-8 bg-gray-100 rounded hover:bg-gray-200 transition-colors duration-300 font-semibold text-gray-700"
                            >
                              +
                            </button>
                          </div>

                          <button
                            onClick={() => setItemToRemove(item.variant.id)}
                            className="text-gray-400 hover:text-red-600 transition-colors duration-300"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>

                <Link
                  to="/products"
                  className="inline-block mt-6 text-primary hover:text-primary-700 font-medium"
                >
                  ← Continue Shopping
                </Link>
              </div>

              {/* Cart Summary */}
              <div>
                <div className="bg-white rounded-xl shadow-md p-6 sticky top-24">
                  <h2 className="text-2xl font-bold text-gray-900 mb-6">
                    Order Summary
                  </h2>

                  <div className="space-y-4 mb-6">
                    <div className="flex justify-between text-gray-700">
                      <span>Subtotal</span>
                      <span className="font-semibold">{format(cartTotal)}</span>
                    </div>
                    <div className="flex justify-between text-gray-700">
                      <span>Shipping</span>
                      <span className="font-semibold">
                        {shippingCost === 0 ? 'FREE' : format(shippingCost)}
                      </span>
                    </div>
                    <div className="flex justify-between text-gray-700">
                      <span>Tax (Est. 8%)</span>
                      <span className="font-semibold">{format(taxAmount)}</span>
                    </div>
                    <div className="border-t pt-4 flex justify-between text-xl font-bold text-gray-900">
                      <span>Total</span>
                      <span>{format(finalTotal)}</span>
                    </div>
                  </div>

                  {cartTotal > 50 && cartTotal < 100 && (
                    <div className="bg-primary-50 text-primary-700 p-3 rounded-lg text-sm mb-4">
                      Add {format(100 - cartTotal)} more for FREE shipping!
                    </div>
                  )}

                  {shippingCost === 0 && cartTotal > 0 && (
                    <div className="bg-green-50 text-green-700 p-3 rounded-lg text-sm mb-4">
                      🎉 You've unlocked FREE shipping!
                    </div>
                  )}

                  <button
                    onClick={handleCheckout}
                    disabled={isCheckingOut}
                    className="w-full bg-primary text-white py-4 px-6 rounded-lg font-semibold hover:bg-primary-700 transition-all duration-300 hover:shadow-lg hover:scale-105 text-center flex justify-center items-center gap-2"
                  >
                    {isCheckingOut ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      'Proceed to Checkout'
                    )}
                  </button>

                  <p className="text-xs text-gray-600 text-center mt-4">
                    Secure checkout powered by Stripe
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Remove Item Confirmation Dialog */}
      <AlertDialog open={!!itemToRemove} onOpenChange={() => setItemToRemove(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove item from cart?</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to remove this item from your shopping cart?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-primary hover:bg-primary-700" onClick={handleRemoveItem}>Remove</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default CartPage;
