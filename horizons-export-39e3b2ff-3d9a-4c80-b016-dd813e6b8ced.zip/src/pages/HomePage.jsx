
import React from 'react';
import { Helmet } from 'react-helmet';
import Hero from '@/components/Hero';
import TrustBadges from '@/components/TrustBadges';
import FeaturedProducts from '@/components/FeaturedProducts';
import TestimonialsSection from '@/components/TestimonialsSection';
import PromotionsSection from '@/components/PromotionsSection';

const HomePage = () => {
  return (
    <>
      <Helmet>
        <title>Confitone - Premium Compression Wear | Elevate Your Performance</title>
        <meta
          name="description"
          content="Experience premium compression wear with Confitone's new management and exceptional quality. See results in 30-45 days with our trademark Confitone material."
        />
      </Helmet>
      
      <div>
        <Hero />
        <TrustBadges />
        <FeaturedProducts />
        <TestimonialsSection />
        <PromotionsSection />
      </div>
    </>
  );
};

export default HomePage;
