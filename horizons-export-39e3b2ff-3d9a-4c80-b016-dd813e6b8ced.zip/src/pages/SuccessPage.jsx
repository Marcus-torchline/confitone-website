
import React from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Check, ShoppingBag, ArrowRight, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';

const SuccessPage = () => {
  const [searchParams] = useSearchParams();
  const orderId = searchParams.get('order_id') || 'CNF-' + Math.random().toString(36).substr(2, 9).toUpperCase();

  return (
    <>
      <Helmet>
        <title>Order Confirmed - Confitone</title>
        <meta name="description" content="Thank you for your purchase!" />
      </Helmet>

      <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="max-w-md w-full bg-white rounded-2xl shadow-xl overflow-hidden"
        >
          <div className="p-8 text-center">
            <motion.div 
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
              className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6"
            >
              <Check className="w-12 h-12 text-green-600" strokeWidth={3} />
            </motion.div>

            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Payment Successful!
            </h1>
            
            <p className="text-gray-600 mb-8">
              Thank you for your purchase. Your order has been confirmed and will be shipped shortly.
            </p>

            <div className="bg-gray-50 rounded-xl p-4 mb-8 border border-gray-100">
              <p className="text-sm text-gray-500 mb-1">Order Reference</p>
              <p className="text-lg font-mono font-bold text-primary tracking-wider">
                {orderId}
              </p>
            </div>

            <div className="space-y-3">
              <Link to="/products">
                <Button className="w-full bg-primary hover:bg-primary-700 text-white font-semibold py-6 text-lg shadow-lg hover:shadow-xl transition-all">
                  <ShoppingBag className="mr-2 h-5 w-5" />
                  Continue Shopping
                </Button>
              </Link>
              
              <Link to="/">
                <Button variant="ghost" className="w-full text-gray-600 hover:bg-gray-100 py-6">
                  <Home className="mr-2 h-5 w-5" />
                  Return to Home
                </Button>
              </Link>
            </div>
          </div>
          
          <div className="bg-primary-50 p-4 text-center border-t border-primary-100">
            <p className="text-sm text-primary-700">
              A confirmation email has been sent to your inbox.
            </p>
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default SuccessPage;
